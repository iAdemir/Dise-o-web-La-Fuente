var topp = 0;
var left = 0;

function travel(direction)
{
	switch(direction)
	{
		case "up":
			topp = topp - 20;
			break;
		case "left":
			left = left -20;
			break;
		case "down":
			topp = topp + 20;
			break;
		case "right":
			left = left + 20;
			break;
	}
	document.getElementById("mario").style.top = topp + "px";
	document.getElementById("mario").style.left = left + "px";
}
